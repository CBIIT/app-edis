"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
// This is the entrypoint for the package
const path = __importStar(require("path"));
const ts_lambda_api_1 = require("ts-lambda-api");
const aws_sdk_1 = require("aws-sdk");
const Config_1 = require("./conf/Config");
const SECRET = process.env.SECRET || 'era-commons-connect';
const appConfig = new Config_1.Config();
const secretsClient = new aws_sdk_1.SecretsManager({ region: 'us-east-1' });
appConfig.base = "/generatets/v1";
appConfig.version = "v1";
appConfig.serverLogger.level = ts_lambda_api_1.LogLevel.debug;
let configuration;
const controllerPath = [path.join(__dirname, "controllers")];
const app = new ts_lambda_api_1.ApiLambdaApp(controllerPath, appConfig);
app.configureApp(container => {
    container.bind(Config_1.Config).toConstantValue(appConfig);
});
async function handler(event, context) {
    if (!configuration) {
        console.debug('Getting secret parameters...');
        configuration = await getSecretParameters();
        appConfig.initConfiguration(configuration);
    }
    return await app.run(event, context);
}
exports.handler = handler;
async function getSecretParameters() {
    const input = {
        SecretId: SECRET
    };
    const data = await secretsClient.getSecretValue(input).promise();
    if (data) {
        if (data.SecretString) {
            return JSON.parse(data.SecretString);
        }
    }
    else {
        console.error('SecretsManager Success: NO ERR OR DATA');
        throw new Error('SecretsManager Success: NO ERR OR DATA');
    }
}
// export * from './api/apis';
// export * from './model/models';
