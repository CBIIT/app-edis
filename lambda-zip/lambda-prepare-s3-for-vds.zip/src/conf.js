
const conf = {
    IC: [
        'CC',
        'CIT',
        'CSR',
        'FIC',
        'NCATS',
        'NCCIH',
        'NCI',
        'NEI',
        'NHGRI',
        'NHLBI',
        'NIA',
        'NIAAA',
        'NIAID',
        'NIAMS',
        'NIBIB',
        'NICHD',
        'NIDA',
        'NIDCD',
        'NIDCR',
        'NIDDK',
        'NIEHS',
        'NIGMS',
        'NIMH',
        'NIMHD',
        'NINDS',
        'NINR',
        'NLM',
        'OD'
    ]
}

module.exports = { conf }
