"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NedController = void 0;
const inversify_1 = require("inversify");
const ts_lambda_api_1 = require("ts-lambda-api");
const getNEDChangesByIC200Response_1 = require("../model/getNEDChangesByIC200Response");
const soap_1 = require("soap");
const WSSecurity = require("wssecurity");
const Config_1 = require("../conf/Config");
let NedController = class NedController extends ts_lambda_api_1.Controller {
    constructor(conf) {
        super();
        this.conf = conf;
    }
    async getChangesByIC(ic, fromDate, fromTime, toDate, toTime, Testing) {
        try {
            if (Testing) {
                console.info(`Return in Testing mode - no actual call is performed`);
                return { 'Success': true };
            }
            return await this._getChangesByIc(ic, fromDate, fromTime, toDate, toTime);
        }
        catch (error) {
            console.error(error);
            this.response.status(500).send(error);
        }
    }
    async _getChangesByIc(ic, fromDate, fromTime, toDate, toTime) {
        console.info(`Getting NED changes by IC`, ic, fromDate, fromTime, toDate, toTime);
        const args = {
            ICorSITE: ic,
            From_Date: fromDate,
        };
        if (fromTime) {
            args['From_time'] = fromTime;
        }
        if (toDate) {
            args['To_Date'] = toDate;
        }
        if (toTime) {
            args['To_time'] = toTime;
        }
        console.debug(`Continue in real mode `, args);
        const client = await this._getSoapClientForNedChanges();
        const result = await client.ByICAsync(args);
        return (Array.isArray(result) && result.length > 0) ? result[0] : result;
    }
    // async _getSoapClientForNed() {
    //     if (!this.soapClient) {
    //         this.soapClient = await createClientAsync(this.conf.ned.wsdl);
    //         this.soapClient.setSecurity(this._getWsSecurity_v7());
    //     }
    //     return this.soapClient;
    // }
    async _getSoapClientForNedChanges() {
        if (!this.soapClientForChanges) {
            console.debug('createClientAsync() for ', this.conf.ned.wsdl_changes);
            this.soapClientForChanges = await (0, soap_1.createClientAsync)(this.conf.ned.wsdl_changes);
            this.soapClientForChanges.setSecurity(this._getWsSecurity_v7());
        }
        return this.soapClientForChanges;
    }
    _getWsSecurity_v7() {
        if (!this.wsSecurity_v7) {
            this.wsSecurity_v7 = new WSSecurity(this.conf.ned.user, this.conf.ned.pwd);
        }
        return this.wsSecurity_v7;
    }
};
__decorate([
    (0, ts_lambda_api_1.GET)("/changesByIc/:ic"),
    (0, ts_lambda_api_1.apiOperation)({ name: "List NED Changes for the given IC", description: "List NED Change records that satisfy given IC criteria" }),
    (0, ts_lambda_api_1.apiResponse)(200, { class: getNEDChangesByIC200Response_1.GetNEDChangesByIC200Response }),
    __param(0, (0, ts_lambda_api_1.pathParam)("ic")),
    __param(1, (0, ts_lambda_api_1.queryParam)("fromDate")),
    __param(2, (0, ts_lambda_api_1.queryParam)("fromTime")),
    __param(3, (0, ts_lambda_api_1.queryParam)("toDate")),
    __param(4, (0, ts_lambda_api_1.queryParam)("toTime")),
    __param(5, (0, ts_lambda_api_1.queryParam)("Testing")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, Boolean]),
    __metadata("design:returntype", Promise)
], NedController.prototype, "getChangesByIC", null);
NedController = __decorate([
    (0, ts_lambda_api_1.apiController)("/generatets/v1/ned"),
    (0, ts_lambda_api_1.api)("NED APIs Controller", "API endpoints to retrieve data from NED"),
    ts_lambda_api_1.controllerNoAuth,
    (0, inversify_1.injectable)(),
    __param(0, (0, inversify_1.inject)(Config_1.Config)),
    __metadata("design:paramtypes", [Config_1.Config])
], NedController);
exports.NedController = NedController;
