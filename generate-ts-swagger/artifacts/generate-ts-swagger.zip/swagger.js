"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = __importStar(require("path"));
const ts_lambda_api_local_1 = require("ts-lambda-api-local");
const ts_lambda_api_1 = require("ts-lambda-api");
const typed_rest_client_1 = require("typed-rest-client");
const fs = __importStar(require("fs"));
const yaml = __importStar(require("js-yaml"));
const args = process.argv.slice(2);
console.log('ARGUMENTS:', args);
const OUTPUT_PATH = (args && args.length > 0) ? args[0] : '../out';
const table = args[0];
let appConfig = new ts_lambda_api_1.AppConfig();
appConfig.name = "User REST Web Service API";
// appConfig.base = "/generatets/v1";
appConfig.version = "0.1.0";
appConfig.openApi.enabled = true;
appConfig.openApi.useAuthentication = false;
let controllers = [path.join(__dirname, "./controllers")];
let app = new ts_lambda_api_local_1.ApiConsoleApp(controllers, appConfig);
let restClient = new typed_rest_client_1.RestClient("swagger-test", "http://localhost:8080", null, { allowRedirects: false });
let httpClient = restClient.client;
async function generate() {
    await app.runServer([]);
    let response = await httpClient.get("http://localhost:8080/open-api.json");
    let body = await response.readBody();
    let jsonBody = JSON.parse(body);
    Object.entries(jsonBody['paths']).forEach(([key, path]) => {
        Object.entries(path).forEach(([key, method]) => {
            //  We are in body.paths.<path>.<method>
            method['x-amazon-apigateway-integration'] = {
                uri: '${lambda_invoke_arn}',
                httpMethod: 'POST',
                timeoutInMillis: 29000,
                type: 'aws_proxy'
            };
        });
    });
    console.log('Response:', jsonBody);
    let yamlBody = yaml.dump(jsonBody);
    fs.writeFileSync(path.join(__dirname, OUTPUT_PATH + "/generate-ts-swagger.yml"), yamlBody);
    await app.stopServer();
}
generate();
